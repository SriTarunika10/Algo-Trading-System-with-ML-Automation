# app.py
import streamlit as st
import pandas as pd
from datetime import date
from fetch_data import fetch_all_data
from strategy import run_strategy
from ml_model import train_model
from gsheet_logger import log_signals_to_sheet
from telegram_bot import send_telegram_message

# Setup
st.set_page_config(page_title="Algo-Trading System", layout="wide", initial_sidebar_state="expanded")
st.title("🤖📈 Algo-Trading System with ML & Automation")

st.markdown(
    """
    <style>
    .stMetric {
        background-color: #f0f2f6;
        border-radius: 10px;
        padding: 10px;
    }
    .main > div {
        padding-top: 0rem;
    }
    </style>
    """, unsafe_allow_html=True
)

# Define available stocks
STOCKS = [
    "RELIANCE.NS", "INFY.NS", "TCS.NS",
    "HDFCBANK.NS", "ICICIBANK.NS", "WIPRO.NS",
    "SBIN.NS", "LT.NS", "AXISBANK.NS"
]

with st.sidebar:
    st.header("📌 Configuration")
    selected_stocks = st.multiselect("Select Stocks", STOCKS, default=STOCKS)
    run = st.button("🔁 Run Strategy")

# Run strategy if triggered
if run and selected_stocks:
    st.info(f"📡 Running analysis for selected stocks...")
    all_signals = []
    date_today = date.today().strftime('%Y-%m-%d')

    for stock in selected_stocks:
        with st.spinner(f"Processing {stock}..."):
            df = fetch_all_data(stock)

            if df.empty or 'Close' not in df.columns:
                st.error(f"⚠️ Skipped {stock} — No valid data or missing 'Close' column.")
                continue

            # Flatten multi-index if present
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = ['_'.join(col).strip() for col in df.columns]

            df, signals = run_strategy(df, stock)

            try:
                model, accuracy = train_model(df)
            except Exception as e:
                st.error(f"⚠️ ML model failed for {stock}: {e}")
                continue

            with st.container():
                st.markdown(f"### 📈 {stock} - Technical Overview")

                col1, col2 = st.columns(2)
                with col1:
                    st.metric(label=f"{stock} ML Accuracy", value=f"{accuracy*100:.2f} %")
                with col2:
                    st.markdown(f"`Latest Close:` {df['Close'].iloc[-1]:.2f} ₹")

                # Line charts
                price_cols = [col for col in df.columns if any(k in col for k in ['Close', '20DMA', '50DMA'])]
                if price_cols:
                    st.line_chart(df[price_cols])
                else:
                    st.warning("📉 Missing price indicators.")

                if 'RSI' in df.columns:
                    st.line_chart(df[['RSI']])
                else:
                    st.warning("📉 RSI not available.")

                # Signal DataFrame
                if signals:
                    st.success(f"✅ {len(signals)} Signal(s) generated for {stock}")
                    st.dataframe(pd.DataFrame(signals))
                    all_signals.extend(signals)
                else:
                    st.info(f"ℹ️ No signals generated for {stock}")

    # Final summary
    if all_signals:
        log_signals_to_sheet(all_signals)
        # Group unique stock names
        unique_stocks = sorted(set([s["Stock"] for s in all_signals]))
        pretty_list = "\n".join([f"• {stk}" for stk in unique_stocks])

        telegram_msg = (
            f"📅 Trade Signals for {date_today}\n\n"
            f"📌 You can consider buying the following stocks today:\n"
            f"{pretty_list}\n\n"
            f"✅ Good luck with your trades!"
        )

        send_telegram_message(
            "8024525119:AAGPz79Y1P6EYK_9wK-oXtxO_2oDl7E8CKs",
            "1373362452",
            telegram_msg
        )
        st.success("✅ Signals logged to Google Sheets and Telegram alert sent!")
    else:
        st.warning("📭 No signals generated for any stock today.")
