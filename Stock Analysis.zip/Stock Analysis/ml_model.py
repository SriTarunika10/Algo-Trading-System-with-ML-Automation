# ml_model.py
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd

def add_labels(df):
    # Target: 1 if next day Close > today Close, else 0
    df['Target'] = (df['Close'].shift(-1) > df['Close']).astype(int)
    return df

def train_model(df):
    df = df.copy()

    if not all(x in df.columns for x in ['RSI', 'Volume', 'Close']):
        return None, 0.0  # Return zero accuracy if features missing

    df = add_labels(df)
    df.dropna(inplace=True)

    X = df[['RSI', 'Volume', 'Close']]
    y = df['Target']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    model = DecisionTreeClassifier()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    return model, accuracy
