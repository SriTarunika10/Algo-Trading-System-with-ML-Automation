import gspread
from oauth2client.service_account import ServiceAccountCredentials
import yfinance as yf
import datetime

def log_signals_to_sheet(signals):
    if not signals:
        return

    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
    client = gspread.authorize(creds)

    sheet = client.open("AlgoTradingLog")

    # Create sheets if missing
    try:
        trade_log = sheet.worksheet("Trade_Log")
    except:
        trade_log = sheet.add_worksheet(title="Trade_Log", rows="1000", cols="10")
        trade_log.append_row(["Date", "Stock", "Buy Price", "Sell Price", "P&L", "Result"])

    try:
        summary = sheet.worksheet("Summary")
    except:
        summary = sheet.add_worksheet(title="Summary", rows="10", cols="2")
        summary.append_row(["Metric", "Value"])

    wins = 0
    total = 0
    total_profit = 0

    for signal in signals:
        date = str(signal['Date'])
        stock = str(signal['Stock'])
        buy_price = float(signal['Close'])

        # Fetch next-day close price
        df = yf.download(stock, start=date, end=None, interval='1d', progress=False)
        dates = df.index[df.index > date]
        if not dates.empty:
            next_day = df.loc[dates[0]]
            sell_price = float(next_day['Close'])
        else:
            sell_price = buy_price  # assume break-even

        profit = sell_price - buy_price
        result = "Win" if profit > 0 else "Loss"
        wins += profit > 0
        total += 1
        total_profit += profit

        trade_log.append_row([date, stock, buy_price, sell_price, round(profit, 2), result])

    # Clear and rewrite summary
    summary.clear()
    summary.append_row(["Metric", "Value"])
    summary.append_row(["Total Trades", total])
    summary.append_row(["Winning Trades", wins])
    summary.append_row(["Total P&L", round(total_profit, 2)])
    summary.append_row(["Win Ratio (%)", round((wins / total) * 100, 2) if total else 0])
def log_pnl_to_sheet(pnl_data):
    if not pnl_data:
        return

    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
    client = gspread.authorize(creds)
    sheet = client.open("AlgoTradingLog")

    try:
        pnl_sheet = sheet.worksheet("PnL_Log")
    except:
        pnl_sheet = sheet.add_worksheet(title="PnL_Log", rows="1000", cols="10")
        pnl_sheet.append_row(["Date", "Stock", "Buy Price", "Sell Price", "P&L", "Result"])

    for row in pnl_data:
        pnl_sheet.append_row(row)
