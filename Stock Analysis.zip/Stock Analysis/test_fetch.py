from fetch_data import fetch_all_data

STOCKS = [
    "RELIANCE.NS", "INFY.NS", "TCS.NS",
    "HDFCBANK.NS", "ICICIBANK.NS", "WIPRO.NS",
    "SBIN.NS", "LT.NS", "AXISBANK.NS"
]

for stock in STOCKS:
    df = fetch_all_data(stock)
    print(f"{stock} ✅ {df.shape if not df.empty else '❌ Empty or Invalid'}")
    print("-" * 50)
