import yfinance as yf
import pandas as pd

def fetch_all_data(ticker):
    data = yf.download(ticker, period='6mo', interval='1d', auto_adjust=True, progress=False)

    if data.empty:
        print(f"[ERROR] No data fetched for {ticker}")
        return pd.DataFrame()

    # Flatten MultiIndex columns (if any)
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = [col[0] if isinstance(col, tuple) else col for col in data.columns]

    print(f"[INFO] {ticker} columns after flattening: {data.columns.tolist()}")

    if 'Close' not in data.columns:
        print(f"[ERROR] 'Close' column still missing for {ticker}")
        return pd.DataFrame()

    data.dropna(inplace=True)
    return data
