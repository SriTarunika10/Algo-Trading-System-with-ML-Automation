import pandas as pd

def calculate_indicators(df):
    if 'Close' not in df.columns:
        raise KeyError(f"'Close' column missing in DataFrame. Columns: {df.columns.tolist()}")

    df = df.copy()

    # Moving Averages
    df['20DMA'] = df['Close'].rolling(window=20).mean()
    df['50DMA'] = df['Close'].rolling(window=50).mean()

    # RSI Calculation
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0).rolling(14).mean()
    loss = -delta.where(delta < 0, 0).rolling(14).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))

    df.dropna(inplace=True)
    return df

def run_strategy(df, stock_name):
    try:
        df = calculate_indicators(df)
    except KeyError as e:
        print(f"[ERROR] Skipping {stock_name}: {e}")
        return df, []

    signals = []
    for i in range(1, len(df)):
        # Relaxed strategy: RSI < 40 and simple 20DMA > 50DMA
        if (
            df['RSI'].iloc[i] < 40 and
            df['20DMA'].iloc[i] > df['50DMA'].iloc[i]
        ):
            signal = {
                "Date": df.index[i].strftime('%Y-%m-%d'),
                "Stock": stock_name,
                "Close": float(df['Close'].iloc[i]),
                "Signal": "BUY"
            }
            signals.append(signal)

    return df, signals
